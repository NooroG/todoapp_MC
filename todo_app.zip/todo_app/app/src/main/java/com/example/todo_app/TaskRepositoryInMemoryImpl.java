package com.example.todo_app;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import java.util.ArrayList;
import java.util.List;

public class TaskRepositoryInMemoryImpl implements TaskRepository {

    private static TaskRepositoryInMemoryImpl instance;
    private List<Task> mTasks;
    private MutableLiveData<List<Task>> tasksLiveData = new MutableLiveData<>();

    public static synchronized TaskRepositoryInMemoryImpl getInstance() {
        if (instance == null) {
            instance = new TaskRepositoryInMemoryImpl();
        }
        return instance;
    }

    private TaskRepositoryInMemoryImpl() {
        mTasks = new ArrayList<>();
        tasksLiveData.setValue(mTasks);

    }

    @Override
    public LiveData<List<Task>> getAllTasksLiveData() {
        return tasksLiveData;
    }

    @Override
    public List<Task> loadTasks(Task task) {
        // no need rn
        return null;
    }

    @Override
    public List<Task> loadTasks() {
        return new ArrayList<>(mTasks);
    }

    @Override
    public void deleteFinishedTasks() {
        mTasks.removeIf(Task::isDone);
    }

    @Override
    public void addTask(Task task) {
        mTasks.add(task);
        tasksLiveData.setValue(mTasks);
    }

    @Override
    public void updateTask(Task task) {
        for (int i = 0; i < mTasks.size(); i++) {
            if (mTasks.get(i).getId() == task.getId()) {
                mTasks.set(i, task);
                tasksLiveData.setValue(mTasks);
                break;
            }
        }
    }

    @Override
    public List<Task> getAllTasks() {
        return new ArrayList<>(mTasks);
    }

    @Override
    public Task getTaskById(int taskId) {
        for (Task task : mTasks) {
            if (task.getId() == taskId) {
                return task;
            }
        }
        return null;
    }
}
