package com.example.todo_app;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Date;

public class AddTaskActivity extends AppCompatActivity {

    private EditText shortNameEditText;
    private EditText descriptionEditText;
    private CheckBox doneCheckBox;
    private TextView dateTextView;
    private TextView cdateTextView;
    private TaskRepository taskRepository;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
    private int taskId;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rvtask);
        taskRepository = TaskRepositoryInMemoryImpl.getInstance();
        shortNameEditText = findViewById(R.id.editTask);
        descriptionEditText = findViewById(R.id.descriptionText);
        doneCheckBox = findViewById(R.id.checkbox);
        dateTextView = findViewById(R.id.dateTextView);
        cdateTextView = findViewById(R.id.Creationdate);
        Button saveButton = findViewById(R.id.saveButton);
        Button backButton = findViewById(R.id.backbutton);

        dateTextView.setOnClickListener(view -> showDatePickerDialog());
        saveButton.setOnClickListener(view -> saveTask());
        backButton.setOnClickListener(view -> finish());

        taskId = getIntent().getIntExtra("task_id", -1);
        if (taskId != -1) {
            Task task = taskRepository.getTaskById(taskId);
            shortNameEditText.setText(task.getShortName());
            descriptionEditText.setText(task.getDescription());
            doneCheckBox.setChecked(task.isDone());
            dateTextView.setText(task.getDueDate());
            cdateTextView.setText(task.getCreationDate().toString());
            if (selectedDate != null) {
                dateTextView.setText(selectedDate);
            }
        }

        if (savedInstanceState != null) {
            selectedDate = savedInstanceState.getString("selected_date");
            if (selectedDate != null) {
                dateTextView.setText(selectedDate);
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("selected_date", selectedDate);
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new DatePickerDialog(AddTaskActivity.this, (view, year1, monthOfYear, dayOfMonth) -> {
            calendar.set(year1, monthOfYear, dayOfMonth);
            selectedDate = dateFormat.format(calendar.getTime());
            dateTextView.setText(dateFormat.format(calendar.getTime()));
        }, year, month, day).show();
    }

    private void saveTask() {
        String name = shortNameEditText.getText().toString();
        String description = descriptionEditText.getText().toString();
        boolean isDone = doneCheckBox.isChecked();

        String creationDate = dateFormat.format(Calendar.getInstance().getTime());

        // makes sure selectedDate is not null
        String dueDate = selectedDate != null ? selectedDate.toString() : "";

        if (taskId != -1) {
            Task task = taskRepository.getTaskById(taskId);
            if (task != null) {
                task.setShortName(name);
                task.setDescription(description);
                task.setDueDate(dueDate);
                task.setDone(isDone);
                taskRepository.updateTask(task);
            } else {
                // Hi

            }
        } else {
            Task newTask = new Task(name, description, dueDate, isDone);
            taskRepository.addTask(newTask);
        }

        finish();
    }
}
