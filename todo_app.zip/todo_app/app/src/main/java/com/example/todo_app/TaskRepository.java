package com.example.todo_app;
import androidx.lifecycle.LiveData;
import java.util.List;

public interface TaskRepository {
    LiveData<List<Task>> getAllTasksLiveData();

    List<Task> loadTasks(Task task);


    List<Task> loadTasks();

    void deleteFinishedTasks();
    void addTask(Task task);
    void updateTask(Task task);
    List<Task> getAllTasks();
    Task getTaskById(int taskId);
}
