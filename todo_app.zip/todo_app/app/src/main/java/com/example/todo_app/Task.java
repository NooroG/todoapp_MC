package com.example.todo_app;

import java.util.Date;
import java.util.GregorianCalendar;

public class Task {

    private static int MAX_ID = 0;


    private int mId;
    private String mShortName;
    private String mDescription;
    private Date mCreationDate;
    private boolean mDone;
    private String mDueDate;

    public Task(String shortName, String description, String dueDate, boolean isDone) {
        this.mId = MAX_ID++;
        this.mShortName = shortName;
        this.mDescription = description;
        this.mCreationDate = GregorianCalendar.getInstance().getTime();
        this.mDueDate = dueDate;
        this.mDone = isDone;
    }

    // Getters and Setters

    public int getId() {
        return this.mId;
    }

    public String getShortName() {
        return this.mShortName;
    }

    public void setShortName(String shortName) {
        this.mShortName = shortName;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        this.mDescription = description;
    }

    public String getDueDate() {
        return mDueDate;
    }
    public void setDueDate(String dueDate) {
        this.mDueDate = dueDate;
    }

    public Date getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.mCreationDate = creationDate;
    }

    public boolean isDone() {
        return mDone;
    }

    public void setDone(boolean done) {
        this.mDone = done;
    }

    @Override
    public String toString() {
        return this.mShortName;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Task) {
            return this.getId() == ((Task) obj).getId();
        }
        return false;
    }
}
