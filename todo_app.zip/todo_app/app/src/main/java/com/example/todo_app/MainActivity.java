package com.example.todo_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private todo_RecyclerViewAdapter adapter;
    private List<Task> taskList;
    private TaskRepository taskRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.mRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskRepository = TaskRepositoryInMemoryImpl.getInstance();
        taskList = taskRepository.getAllTasks();

        adapter = new todo_RecyclerViewAdapter(this, taskList, taskRepository);
        recyclerView.setAdapter(adapter);

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        taskList.clear();
        taskList.addAll(taskRepository.getAllTasks());
        adapter.notifyDataSetChanged();
    }


}

/*
transaction
TaskDetailFragment newDetailFragment = new TaskDetailFragment();
Bundle args = new Bundle();
args.putInt(TaskDetailFragment.ARG_TASK_ID, task.getId());
newDetailFragment.setArguments(args);

getSupportFragmentManager().beginTransaction()
        .replace(R.id.detail_fragment, newDetailFragment)
        .addToBackStack(null)
        .commit();
*/