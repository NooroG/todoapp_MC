package com.example.todo_app;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;



public class todo_RecyclerViewAdapter extends RecyclerView.Adapter<todo_RecyclerViewAdapter.MyViewHolder> {

    Context context;
    List<Task> mTasks;
    TaskRepository taskRepository;

    public todo_RecyclerViewAdapter(Context context, List<Task> mTasks,TaskRepository taskRepository) {
        this.context = context;
        this.mTasks = mTasks;
        this.taskRepository = taskRepository;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.taskrow, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Task task = mTasks.get(position);
        holder.taskNameTextView.setText(task.getShortName());
        holder.descriptionTextView.setText(task.getDescription());
        holder.dueDateTextView.setText(task.getDueDate().toString());
        holder.doneCheckBox.setChecked(task.isDone());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, AddTaskActivity.class);
                intent.putExtra("task_id", task.getId());
                context.startActivity(intent);
            }
        });
        holder.doneCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setDone(isChecked);
            taskRepository.updateTask(task); // update in repo
        });
    }

    @Override
    public int getItemCount() {
        return mTasks.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView taskNameTextView, descriptionTextView, dueDateTextView;
        CheckBox doneCheckBox;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            taskNameTextView = itemView.findViewById(R.id.taskNameTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
            dueDateTextView = itemView.findViewById(R.id.dueDateTextView);
            doneCheckBox = itemView.findViewById(R.id.doneCheckBox);
        }
    }
}
