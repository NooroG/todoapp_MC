package com.example.todo_app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class TaskDetailFragment extends Fragment {
    private EditText editTaskName;
    private EditText editDescription;
    private TextView dueDateText;
    private TextView creationDateText;
    private CheckBox doneCheckBox;
    private Button saveButton;
    private Task selectedTask;
    private TaskRepository taskRepository;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_task_detail, container, false);

        editTaskName = rootView.findViewById(R.id.editTask);
        editDescription = rootView.findViewById(R.id.descriptionText);
        dueDateText = rootView.findViewById(R.id.dateTextView);
        creationDateText = rootView.findViewById(R.id.Creationdate);
        doneCheckBox = rootView.findViewById(R.id.checkbox);
        saveButton = rootView.findViewById(R.id.saveButton);

        // Initialize taskRepository if needed

        if (savedInstanceState != null) {
            // Restore fragment state here if needed
        }

        return rootView;
    }

    public void updateTaskDetails(Task task) {
        selectedTask = task;
        if (task != null) {
            editTaskName.setText(task.getShortName());
            editDescription.setText(task.getDescription());
            dueDateText.setText(task.getDueDate().toString());
            creationDateText.setText(task.getCreationDate().toString());
            doneCheckBox.setChecked(task.isDone());
        }
    }

    private void saveTaskDetails() {
        if (selectedTask != null) {
            selectedTask.setShortName(editTaskName.getText().toString());
            selectedTask.setDescription(editDescription.getText().toString());
            selectedTask.setDone(doneCheckBox.isChecked());

            // Update task in repository
            taskRepository.updateTask(selectedTask);

            // Notify listener or update UI as needed
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save fragment state here if needed
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null) {
            // Restore fragment state here if needed
        }
    }
}