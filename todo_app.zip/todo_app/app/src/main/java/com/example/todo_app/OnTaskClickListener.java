package com.example.todo_app;


public interface OnTaskClickListener {
    void onTaskSelected(Task task);
}
