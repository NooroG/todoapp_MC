package com.example.todo_app;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskListFragment extends Fragment {
    private OnTaskClickListener taskSelectedListener;

    private RecyclerView recyclerView;
    private todo_RecyclerViewAdapter adapter;
    private List<Task> taskList;
    private TaskRepository taskRepository;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            taskSelectedListener = (OnTaskClickListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement OnTaskSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_task_list, container, false);

        recyclerView = rootView.findViewById(R.id.taskListRecyclerView); // Ensure this ID matches

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        taskRepository = TaskRepositoryInMemoryImpl.getInstance();
        taskList = taskRepository.getAllTasks();

        adapter = new todo_RecyclerViewAdapter(getActivity(), taskList, taskRepository);
        recyclerView.setAdapter(adapter);

        return rootView;
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save fragment state here if u want
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null) {
            // Restore fragment state here if u want
        }
    }
}