package com.example.todo_app;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import java.util.List;

public class TaskListViewModel extends ViewModel {

    private TaskRepository taskRepository;
    private LiveData<List<Task>> tasksLiveData;

    public TaskListViewModel() {
        taskRepository = TaskRepositoryInMemoryImpl.getInstance();
        tasksLiveData = taskRepository.getAllTasksLiveData();
    }

    public LiveData<List<Task>> getTasksLiveData() {
        return tasksLiveData;
    }

    public void addTask(Task task) {
        taskRepository.addTask(task);
    }

    public void updateTask(Task task) {
        taskRepository.updateTask(task);
    }

   /* public void deleteTask(Task task) {
        taskRepository.deleteTask(task);
    }*/
}
