package com.example.todo_app;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.todo_app.Task;
import com.example.todo_app.TaskRepository;
import java.util.List;

public class TaskViewModel extends ViewModel {

    private TaskRepository taskRepository;

    public TaskViewModel(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public LiveData<List<Task>> getAllTasksLiveData() {
        return taskRepository.getAllTasksLiveData();
    }

    public void addTask(Task task) {
        taskRepository.addTask(task);
    }

    public void updateTask(Task task) {
        taskRepository.updateTask(task);
    }

    /*public void deleteTask(Task task) {
        taskRepository.deleteTask(task);
    }*/

    public Task getTaskById(int taskId) {
        return taskRepository.getTaskById(taskId);
    }
}
